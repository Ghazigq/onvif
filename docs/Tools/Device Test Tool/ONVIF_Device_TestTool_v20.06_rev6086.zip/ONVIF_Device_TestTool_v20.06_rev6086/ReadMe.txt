1. Application Name and Version
======================================

ONVIF Test Tool 20.06


2. System Requirements
======================================

	1. Windows 7 / Windows 10

	2. .NET Framework 4.5
	



3. Installation Instructions:
======================================

	1. Please read 'ONVIF_Device_TestTool_v*_Installation_Guide.docx' file for the detailed instructions.

	2. Run TestTool.Installer_v*_rev*.msi and follow installer instructions.
	
	3. After installation complete, go to Start->Program->ONVIF menu and run aplication.

	4. Please read 'ONVIF_Test_Tool_Intermediate_Release_Notes.pdf' file for the description of this versions' contents.

	5. It would be highly appreciated if you provide your feedback (found bugs) to ONVIF workgroups


On Profile S related items to Maintenance WG: tswg_devicetest@developer.onvif.org

On Profile G related items to Maintenance WG: tswg_devicetest@developer.onvif.org

On maintenance related items to Maintenance WG: tswg_devicetest@developer.onvif.org

On Advanced Securily related items to Security Test WG: tswg_devicetest@developer.onvif.org

On Profile A related items to Maintenance WG: tswg_devicetest@developer.onvif.org

On Profile Q related items to Maintenance WG: tswg_devicetest@developer.onvif.org

On Profile T related items to Maintenance WG: tswg_devicetest@developer.onvif.org

